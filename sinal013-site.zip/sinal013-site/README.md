# SINAL 0.13

ARG / Analog Horror interativo.

Um servidor antigo da **Nexum Transmissões** voltou online sozinho em 2026.  
Ninguém sabe quem restaurou. O Projeto 0.13 não deveria existir mais.

---

## Como publicar no GitHub Pages (grátis)

1. Crie um repositório novo no GitHub (pode ser público ou privado)
2. Faça upload de **todos** os arquivos desta pasta (`index.html` + pasta `assets/`)
3. Vá em **Settings → Pages**
4. Em **Source**, escolha a branch `main` (ou `master`) e a pasta `/ (root)`
5. Clique em Save

Em alguns minutos o site estará no ar em:
`https://SEU-USUARIO.github.io/NOME-DO-REPO/`

Pronto. Funciona perfeitamente no celular.

---

## Estrutura

```
sinal013-site/
├── index.html          ← página principal
├── assets/
│   ├── transmission_01.mp3
│   └── transmission_02.mp3
└── README.md
```

---

Não responda ao sinal.
